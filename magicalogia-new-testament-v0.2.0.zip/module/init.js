/**
 * A simple and flexible system for world-building using an arbitrary collection of character and item attributes
 * Author: Atropos
 * Software License: GNU GPLv3
 */

// Import Modules
import { MagicalogiaActorSheet } from "./sheet/actor-sheet.js";
import { MagicalogiaItemSheet } from "./sheet/item-sheet.js";
import { MagicalogiaActor } from "./document/actor.js";
import { MagicalogiaSettings } from "./settings.js";
import { PlotSettings } from "./plot.js";
import { PlotDialog } from "./dialog/plot-dialog.js";

import { ActorItemToken } from "./document/token.js";
import { migrateWorld, registerMigrationSettings } from "./migration.js";

/* -------------------------------------------- */
/*  Foundry VTT Initialization                  */
/* -------------------------------------------- */

Hooks.once("init", async function() {
    console.log(`Initializing Simple Magicalogia System`);

    Roll.TOOLTIP_TEMPLATE = "systems/magicalogia-new-testament/templates/tooltip.html";

    CONFIG.Actor.documentClass = MagicalogiaActor;
    CONFIG.Token.objectClass = ActorItemToken;

    // Register sheet application classes
    Actors.unregisterSheet("core", ActorSheet);
    Actors.registerSheet("magicalogia-new-testament", MagicalogiaActorSheet, { makeDefault: true });
    Items.unregisterSheet("core", ItemSheet);
    Items.registerSheet("magicalogia-new-testament", MagicalogiaItemSheet, {makeDefault: true});

    // CONFIG.Combat.documentClass = PlotCombat;
    CONFIG.Combat.initiative.formula = "1d6";
    MagicalogiaSettings.init();
    registerMigrationSettings();

    PlotSettings.initPlot();

});


Hooks.once("ready", async function() {
    try {
        await migrateWorld();
    } catch (err) {
        console.error("Magicalogia: migration failed", err);
    }

    let basedoc = document.getElementsByClassName("vtt game system-magicalogia");
    let hotbar = document.createElement("div");
    hotbar.className = "plot-bar";

    if (basedoc[0]) basedoc[0].appendChild(hotbar);
});

Hooks.on("dropCanvasData", async (canvas, data) => {
    if (data.type == "Item") {
        let item = await Item.implementation.fromDropData(data);
        if (item.type != "handout")
            return;

        const hw = canvas.grid.w / 2;
        const hh = canvas.grid.h / 2;
        const pos = canvas.grid.getSnappedPosition(data.x - hw, data.y - hh);

        const token = (await canvas.scene.createEmbeddedDocuments("Token", [{name: item.name, img: item.img, x: pos.x, y: pos.y}], {}))[0];
        await token.setFlag("magicalogia-new-testament", "uuid", data.uuid);
    }

});

Hooks.on("renderChatLog", (app, html, data) => chatListeners(html));
Hooks.on("renderChatPopout", (app, html, data) => chatListeners(html));
Hooks.on("updatePlotBar", (html) => chatListeners(html));

async function chatListeners(html) {
    html.on('click', '.roll-talent', async event => {
        event.preventDefault();
        const data = event.currentTarget.dataset;
        // v0.2.3 fix: resolve actor via the chat message itself (works in V12+).
        let actor = null;
        const li = event.currentTarget.closest("li.chat-message");
        const msgId = li?.dataset?.messageId;
        if (msgId) {
            const msg = game.messages.get(msgId);
            const spk = msg?.speaker;
            if (spk?.token) actor = canvas.tokens?.get(spk.token)?.actor ?? null;
            if (!actor && spk?.actor) actor = game.actors.get(spk.actor);
        }
        if (!actor) {
            const sp = ChatMessage.getSpeaker();
            if (sp.token) actor = canvas.tokens?.get(sp.token)?.actor ?? null;
            if (!actor && sp.actor) actor = game.actors.get(sp.actor);
        }
        // Last resort: the user's assigned character.
        if (!actor) actor = game.user?.character ?? null;
        if (!actor) {
            ui.notifications?.warn("找不到對應角色 — 請先選取 token 或在 user 設定裡指定角色");
            return;
        }
        
        let add = true;
        if (!event.ctrlKey && !game.settings.get("magicalogia-new-testament", "rollAddon"))
          add = false;

        let secret = false;
        if (event.altKey)
          secret = true;
        
        let tmpTitle = data.talent.split(game.i18n.localize("MAGICALOGIA.Tmp"));
        if (tmpTitle.length == 2) {
            let name_id = (tmpTitle[0].trim() == '') ? Math.floor(Math.random() * 6) : null;
            if (name_id == null) {
                for (let i = 0; i < 6; ++i) {
                    let name = String.fromCharCode(65 + i);
                    let title = game.settings.get("magicalogia-new-testament", `MAGICALOGIA.${name}1`);
                    title = (title !== "") ? title : game.i18n.localize(`MAGICALOGIA.${name}1`);
                    if (title == tmpTitle[0].trim())
                        name_id = i;
                }
            }
            let id = Math.floor(Math.random() * 11) + 2;

            let name = String.fromCharCode(65 + name_id);
            let title = game.settings.get("magicalogia-new-testament", `MAGICALOGIA.${name}${id}`);
            title = (title !== "") ? title : game.i18n.localize(`MAGICALOGIA.${name}${id}`);
            let num = actor.system.talent.table[name_id][id - 2].num;
            return actor.rollTalent(title, num, add, secret);

        } else {
            for (var i = 2; i <= 12; ++i)
            for (var j = 0; j < 6; ++j) {
                let name = String.fromCharCode(65 + j);
                let title = game.settings.get("magicalogia-new-testament", `MAGICALOGIA.${name}${i}`);
                title = (title !== "") ? title : game.i18n.localize(`MAGICALOGIA.${name}${i}`);
                
                if (title === data.talent) {
                    let num = actor.system.talent.table[j][i - 2].num;
                    return actor.rollTalent(title, num, add, secret);
                }
            }
        }
    });


    html.on('click', '.plot-dialog', async ev => {
        event.preventDefault();
        const data = ev.currentTarget.dataset;

        const dice = data.dice.split(",");
        let d = new PlotDialog(data.actorId, data.name, data.sender, dice).render(true);
        game.magicalogia.plotDialogs.push(d);

    });
}


Hooks.on("getSceneControlButtons", function(controls) {
    controls[0].tools.push({
        name: "startBattle",
        title: game.i18n.localize("MAGICALOGIA.StartMagicBattle"),
        icon: "fas fa-star-of-david",
        visible: game.user.isGM,
        onClick: () => {
            let makeZone = async () => {
                let targets = game.user.targets;
                if (targets.size != 2)
                    return;

                let data = {};
                let actors = targets.reduce((acc, t) => {
                    acc.push(t.actor);
                    return acc;
                }, []);

                for (let actor of actors) {
                    data[actor.id] = [];

                    await game.user.updateTokenTargets();
                    await Dialog.prompt({
                        title: game.i18n.localize("MAGICALOGIA.SelectObserver"),
                        content: `
                          <h2>
                            ${actor.name}: ${game.i18n.localize("MAGICALOGIA.SelectObserver")}
                          </h2>
                        `,
                        callback: () => {
                            for (let t of game.user.targets)
                                data[actor.id].push(t.actor.id);
                        }
                    });

                }

                let scene = game.scenes.current;
                let magicZone = {};
                if ("magicalogia-new-testament" in scene.flags && "magicZone" in scene.flags["magicalogia-new-testament"])
                    magicZone = duplicate(scene.flags["magicalogia-new-testament"].magicZone);

                let key = actors.map((a) => a.id).sort().join("-");
                magicZone[key] = data;

                console.log(magicZone);
                await scene.setFlag("magicalogia-new-testament", "magicZone", magicZone);
            }

            Dialog.prompt({
                title: game.i18n.localize("MAGICALOGIA.SelectZomeTarget"),
                content: `
                  <h2>
                    ${game.i18n.localize("MAGICALOGIA.SelectZomeTarget")}
                  </h2>
                `,
                callback: () => makeZone()
            });

        },
        button: true
    });

    controls[0].tools.push({
        name: "endBattle",
        title: game.i18n.localize("MAGICALOGIA.StopMagicBattle"),
        icon: "fas fa-star-of-david",
        visible: game.user.isGM,
        onClick: () => {
            let scene = game.scenes.current;
            let magicZone = {};
            if ("magicalogia-new-testament" in scene.flags && "magicZone" in scene.flags["magicalogia-new-testament"])
                magicZone = duplicate(scene.flags["magicalogia-new-testament"].magicZone);

            if (Object.keys(magicZone).length == 0) {
                Dialog.prompt({
                    title: game.i18n.localize("MAGICALOGIA.NotStopBattle"),
                    content: `
                      <h2>
                        ${game.i18n.localize("MAGICALOGIA.NotStopBattle")}
                      </h2>
                    `,
                    callback: () => console.log("Cancel")
                });
                return;
            }


            let content = `<p>${game.i18n.localize("MAGICALOGIA.SelectBattle")}<br><div>`;
            content += '<select id="battle-select-dialog" multiple style="width: 100%; height: 100%">';
    
            for (let pair of Object.keys(magicZone)) {
                let name = pair.split("-");
                let actors = [game.actors.get(name[0]), game.actors.get(name[1])];
                if (actors[0] == undefined || actors[1] == undefined) {
                    magicZone[`-=${pair}`] = {};
                    continue;
                }

                content += `<option value="${pair}">${actors[0].name} - ${actors[1].name}</option>`;
            }
            content += '</select></div>';


            Dialog.prompt({
                title: game.i18n.localize("MAGICALOGIA.SelectBattle"),
                content: content,
                callback: async () => {
                    let selected = $("#battle-select-dialog").val();
                    for (let s of selected) 
                        magicZone[`-=${s}`] = {};

                    await scene.setFlag("magicalogia-new-testament", "magicZone", magicZone);

                }
            });

        },
        button: true
    });







});